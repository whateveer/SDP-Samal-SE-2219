// package builder_design_pattern;

// Define the Vehicle class
class Vehicle
{
  // Private member variables
  private String engine;
  private int wheel;
  private int airbags;

  // Getter for engine
  public String getEngine()
  {
    return this.engine;
  }

  // Getter for wheel
  public int getWheel()
  {
    return this.wheel;
  }

  // Getter for airbags
  public int getAirbags()
  {
    return this.airbags;
  }

  // Private constructor accepting a VehicleBuilder
  private Vehicle(VehicleBuilder builder)
  {
    this.engine = builder.engine;
    this.wheel = builder.wheel;
    this.airbags = builder.airbags;
  }

  // Define the VehicleBuilder class
  public static class VehicleBuilder
  {
    // Private member variables for builder
    private String engine;
    private int wheel;
    private int airbags;

    // Constructor for VehicleBuilder
    public VehicleBuilder(String engine, int wheel)
    {
      this.engine = engine;
      this.wheel = wheel;
    }

    // Method to set airbags and return the builder
    public VehicleBuilder setAirbags(int airbags)
    {
      this.airbags = airbags;
      return this;
    }

    // Method to build a Vehicle using the builder
    public Vehicle build()
    {
      return new Vehicle(this);
    }
  }
}

// Define the main class for demonstration
public class BuilderPattern
{
  // Main method
  public static void main(String[] args)
  {
    // Create a car using the VehicleBuilder with specified engine, wheels, and airbags
    Vehicle car = new Vehicle.VehicleBuilder("1500cc", 4).setAirbags(4).build();

    // Create a bike using the VehicleBuilder with specified engine and wheels (default airbags = 0)
    Vehicle bike = new Vehicle.VehicleBuilder("250cc", 2).build();

    // Print engine, wheel, and airbags for the car
    System.out.println(car.getEngine());
    System.out.println(car.getWheel());
    System.out.println(car.getAirbags());

    // Print engine, wheel, and airbags for the bike
    System.out.println(bike.getEngine());
    System.out.println(bike.getWheel());
    System.out.println(bike.getAirbags());
  }
}
