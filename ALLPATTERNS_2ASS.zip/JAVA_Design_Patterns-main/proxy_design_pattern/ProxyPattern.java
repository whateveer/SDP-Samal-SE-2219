package proxy_design_pattern;  // Package declaration

interface DatabaseExecuter
{
	public void executeDatabase(String query) throws Exception;  // Interface method declaration
}

class DatabaseExecuterImpl implements DatabaseExecuter
{
	@Override
	public void executeDatabase(String query) throws Exception
	{
		System.out.println("Going to execute Query: " + query);  // Implementation of interface method
	}
}

class DatabaseExecuterProxy implements DatabaseExecuter
{
	boolean ifAdmin;  // Boolean variable declaration
	DatabaseExecuterImpl dbExecuter;  // Instance variable declaration

	public DatabaseExecuterProxy(String name, String passwd)  // Constructor definition
	{
		if(name == "Admin" && passwd == "Admin@123")  // Condition check
		{
			ifAdmin = true;  // Set boolean variable if condition is true
		}
		dbExecuter = new DatabaseExecuterImpl();  // Initialize dbExecuter instance
	}

	@Override
	public void executeDatabase(String query) throws Exception  // Implementation of interface method
	{
		if(ifAdmin)  // Check if user is admin
		{
			dbExecuter.executeDatabase(query);  // Execute query if user is admin
		}
		else
		{
			if(query.equals("DELETE"))  // Check if query is DELETE
			{
				throw new Exception("DELETE not allowed for non-admin user");  // Throw exception for non-admin user trying to DELETE
			}
			else
			{
				dbExecuter.executeDatabase(query);  // Execute other queries for non-admin user
			}
		}
	}
}

public class ProxyPattern
{
	public static void main(String[] args) throws Exception
	{
		DatabaseExecuter nonAdminExecuter = new DatabaseExecuterProxy("NonAdmin", "Admin@123");  // Create proxy for non-admin user
		nonAdminExecuter.executeDatabase("DELEE");  // Execute query for non-admin user (misspelled query)

		DatabaseExecuter nonAdminExecuterDELETE = new DatabaseExecuterProxy("NonAdmin", "Admin@123");  // Create proxy for non-admin user
		nonAdminExecuterDELETE.executeDatabase("DELETE");  // Execute DELETE query for non-admin user

		DatabaseExecuter adminExecuter = new DatabaseExecuterProxy("Admin", "Admin@123");  // Create proxy for admin user
		adminExecuter.executeDatabase("DELETE");  // Execute DELETE query for admin user
	}
}
