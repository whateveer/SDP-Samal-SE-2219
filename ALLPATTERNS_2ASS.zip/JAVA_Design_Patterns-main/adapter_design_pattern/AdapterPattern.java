package adapter_design_pattern; // package declaration

// This is an interface named "WebDriver" that declares two methods.
interface WebDriver {
	public void getElement(); // Method to get an element.
	public void selectElement(); // Method to select an element.
}

// This class "ChromeDriver" implements the "WebDriver" interface.
class ChromeDriver implements WebDriver
{
	@Override
	public void getElement()
	{
		System.out.println("Get element from ChromeDriver");
	}

	@Override
	public void selectElement()
	{
		System.out.println("Select element from ChromeDriver");
	}
}

// This class "IEDriver" does not implement the "WebDriver" interface.
class IEDriver
{
	public void findElement()
	{
		System.out.println("Find element from IEDriver");
	}

	public void clickElement()
	{
		System.out.println("Click element from IEDriver");
	}
}

// This class "WebDriverAdapter" implements the "WebDriver" interface and adapts the "IEDriver" class to it.
class WebDriverAdapter implements WebDriver
{
	IEDriver ieDriver;

	// Constructor for the adapter class.
	public WebDriverAdapter(IEDriver ieDriver)
	{
		this.ieDriver = ieDriver;
	}

	@Override
	public void getElement()
	{
		ieDriver.findElement();
	}

	@Override
	public void selectElement()
	{
		ieDriver.clickElement();
	}
}

// This is the main class "AdapterPattern."
public class AdapterPattern
{
	public static void main(String[] args)
	{
		// Creating an instance of "ChromeDriver" and using it.
		ChromeDriver a = new ChromeDriver();
		a.getElement();
		a.selectElement();

		// Creating an instance of "IEDriver" and using it.
		IEDriver e = new IEDriver();
		e.findElement();
		e.clickElement();

		// Creating an instance of "WebDriverAdapter" and using it to adapt "IEDriver" to the "WebDriver" interface.
		WebDriver wID = new WebDriverAdapter(e);
		wID.getElement();
		wID.selectElement();
	}
}
