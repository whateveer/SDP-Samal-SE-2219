package factory_design_pattern;  // Package declaration

abstract class Vehicle
{
	public abstract int getWheel();  // Abstract method to get the number of wheels
	public String toString()  // Override of toString method
	{
		return "Wheel: " + this.getWheel();  // Return wheel information
	}
}

class Car extends Vehicle
{
	int wheel;  // Wheel count for Car
	Car(int wheel)  // Constructor for Car class
	{
		this.wheel = wheel;  // Set wheel count for Car
	}

	@Override
	public int getWheel()  // Override method to get the wheel count for Car
	{
		return this.wheel;  // Return the wheel count for Car
	}
}

class Bike extends Vehicle
{
	int wheel;  // Wheel count for Bike
	Bike(int wheel)  // Constructor for Bike class
	{
		this.wheel = wheel;  // Set wheel count for Bike
	}

	@Override
	public int getWheel()  // Override method to get the wheel count for Bike
	{
		return this.wheel;  // Return the wheel count for Bike
	}
}

class VehicleFactory
{
	public static Vehicle getInstance(String type, int wheel)
	{
		if(type == "car")  // Check if the type is "car"
		{
			return new Car(wheel);  // Return a new Car instance
		}
		else if(type == "bike")  // Check if the type is "bike"
		{
			return new Bike(wheel);  // Return a new Bike instance
		}
		return null;  // Return null if the type is unknown
	}
}

public class FactoryPattern
{
	public static void main(String[] args)  // Main method
	{
		Vehicle car = VehicleFactory.getInstance("car", 4);  // Create a Car instance
		System.out.println(car);  // Print Car information

		Vehicle bike = VehicleFactory.getInstance("bike", 2);  // Create a Bike instance
		System.out.println(bike);  // Print Bike information
	}
}
