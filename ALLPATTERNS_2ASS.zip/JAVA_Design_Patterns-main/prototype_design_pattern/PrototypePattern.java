// Package declaration
package prototype_design_pattern;

// Importing necessary Java classes
import java.util.ArrayList;
import java.util.List;

// Vehicle class implementing Cloneable interface
class Vehicle implements Cloneable
{
  private List<String> vehicleList; // Private list to hold vehicle names

  // Constructor for Vehicle class
  public Vehicle()
  {
    this.vehicleList = new ArrayList<String>(); // Initializing the vehicle list
  }

  // Constructor for Vehicle class with a provided list
  public Vehicle(List<String> list)
  {
    this.vehicleList = list; // Initializing the vehicle list with a provided list
  }

  // Method to insert vehicle data into the list
  public void insertData()
  {
    vehicleList.add("Honda amaze");
    vehicleList.add("Audi A4");
    vehicleList.add("Hyundai Creta");
    vehicleList.add("Maruti Baleno");
    vehicleList.add("Renault Duster");
  }

  // Method to get the vehicle list
  public List<String> getVehicleList()
  {
    return this.vehicleList; // Returning the vehicle list
  }

  // Overriding the clone method to create a copy of the Vehicle object
  @Override
  public Object clone() throws CloneNotSupportedException
  {
    List<String> tempList = new ArrayList<String>(); // Creating a temporary list to hold the cloned vehicle list

    // Copying the vehicle names to the temporary list
    for(String s : this.getVehicleList())
    {
      tempList.add(s);
    }

    return new Vehicle(tempList); // Returning a new Vehicle object with the cloned vehicle list
  }
}

// Main class for the Prototype Pattern
public class PrototypePattern
{
  // Main method
  public static void main(String[] args) throws CloneNotSupportedException
  {
    Vehicle a = new Vehicle(); // Creating a Vehicle object
    a.insertData(); // Inserting data into the vehicle list

    Vehicle b = (Vehicle) a.clone(); // Cloning the Vehicle object
    List<String> list = b.getVehicleList(); // Getting the vehicle list from the cloned object
    list.add("Honda new Amaze"); // Modifying the cloned vehicle list

    System.out.println(a.getVehicleList()); // Printing the original vehicle list
    System.out.println(list); // Printing the modified (cloned) vehicle list

    b.getVehicleList().remove("Audi A4"); // Removing a vehicle from the cloned list
    System.out.println(list); // Printing the modified (cloned) vehicle list
    System.out.println(a.getVehicleList()); // Printing the original vehicle list
  }
}
