package composite_design_pattern; // Package declarator

import java.util.ArrayList; // Importing ArrayList class from java.util package
import java.util.List; // Importing List interface from java.util package

abstract class Account // Abstract class representing an Account
{
  public abstract float getBalance(); // Abstract method to get the balance of an account
}

class DepositeAccount extends Account // Class representing a Deposit Account which extends Account
{
  private String accountNo; // Private variable for account number
  private float accountBalance; // Private variable for account balance

  public DepositeAccount(String accountNo, float accountBalance) // Constructor for DepositAccount
  {
    super(); // Calling the superclass constructor (Account)
    this.accountNo = accountNo; // Initializing account number
    this.accountBalance = accountBalance; // Initializing account balance
  }

  public float getBalance() // Method to get the balance of a Deposit Account
  {
    return accountBalance; // Returning the account balance
  }
}

class SavingAccount extends Account // Class representing a Savings Account which extends Account
{
  private String accountNo; // Private variable for account number
  private float accountBalance; // Private variable for account balance

  public SavingAccount(String accountNo, float accountBalance) // Constructor for SavingAccount
  {
    super(); // Calling the superclass constructor (Account)
    this.accountNo = accountNo; // Initializing account number
    this.accountBalance = accountBalance; // Initializing account balance
  }

  public float getBalance() // Method to get the balance of a Savings Account
  {
    return accountBalance; // Returning the account balance
  }
}

class CompositeAccount extends Account // Class representing a Composite Account which extends Account
{
  private float totalBalance; // Private variable for total balance
  private List<Account> accountList = new ArrayList<Account>(); // List to hold accounts

  public float getBalance() // Method to calculate and get the total balance of the composite account
  {
    totalBalance = 0; // Initializing total balance to zero

    // Iterating through each account in the list
    for (Account f : accountList)
    {
      totalBalance = totalBalance + f.getBalance(); // Adding account balance to the total balance
    }

    return totalBalance; // Returning the total balance
  }

  public void addAccount(Account acc) // Method to add an account to the composite account
  {
    accountList.add(acc); // Adding the account to the list
  }

  public void removeAccount(Account acc) // Method to remove an account from the composite account
  {
    accountList.add(acc); // Adding the account to the list (should be remove instead of add)
  }
}

public class CompositePattern // Main class for the composite design pattern example
{
  public static void main(String[] args) // Main method
  {
    CompositeAccount component = new CompositeAccount(); // Creating a composite account

    // Adding different accounts to the composite account
    component.addAccount(new DepositeAccount("DA001", 100));
    component.addAccount(new DepositeAccount("DA002", 150));
    component.addAccount(new SavingAccount("SA001", 200));

    float totalBalance = component.getBalance(); // Getting the total balance of the composite account
    System.out.println("Total Balance : " + totalBalance); // Printing the total balance
  }
}
