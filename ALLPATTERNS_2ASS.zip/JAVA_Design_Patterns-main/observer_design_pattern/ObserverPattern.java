// Define a package named observer_design_pattern
package observer_design_pattern;

// Import necessary Java classes
import java.util.ArrayList;
import java.util.List;

// Define the Subject interface
interface Subject
{
    void register(Observer obj); // Method to register an observer
    void unregister(Observer obj); // Method to unregister an observer
    void notifyObservers(); // Method to notify all observers
}

// Define a class named DeliveryData that implements the Subject interface
class DeliveryData implements Subject
{
    private List<Observer> observers; // List to hold observers
    private String location; // String to store the location

    // Constructor to initialize the list of observers
    public DeliveryData()
    {
        this.observers = new ArrayList<>();
    }

    // Method to register an observer
    @Override
    public void register(Observer obj)
    {
        observers.add(obj);
    }

    // Method to unregister an observer
    @Override
    public void unregister(Observer obj)
    {
        observers.remove(obj);
    }

    // Method to notify all observers
    @Override
    public void notifyObservers()
    {
        for(Observer obj : observers)
        {
            obj.update(location);
        }
    }

    // Method to notify observers when location changes
    public void locationChanged()
    {
        this.location = getLocation();
        notifyObservers();
    }

    // Method to get location
    public String getLocation()
    {
        return "YPlace";
    }
}

// Define the Observer interface
interface Observer
{
    public void update(String location); // Method to update observer with location
}

// Define a class named Seller that implements the Observer interface
class Seller implements Observer
{
    private String location; // String to store location

    // Method to update observer with location
    @Override
    public void update(String location)
    {
        this.location = location;
        showLocation();
    }

    // Method to show the location of the observer
    public void showLocation()
    {
        System.out.println("Notification at Seller - Current Location: " + location);
    }
}

// Define a class named User that implements the Observer interface
class User implements Observer
{
    private String location; // String to store location

    // Method to update observer with location
    @Override
    public void update(String location)
    {
        this.location = location;
        showLocation();
    }

    // Method to show the location of the observer
    public void showLocation()
    {
        System.out.println("Notification at User - Current Location: " + location);
    }
}

// Define a class named DeliveryWarehouseCenter that implements the Observer interface
class DeliveryWarehouseCenter implements Observer
{
    private String location; // String to store location

    // Method to update observer with location
    @Override
    public void update(String location)
    {
        this.location = location;
        showLocation();
    }

    // Method to show the location of the observer
    public void showLocation()
    {
        System.out.println("Notification at Warehouse - Current Location: " + location);
    }
}

// Define the main class for the Observer Pattern example
public class ObserverPattern
{
    public static void main(String[] args)
    {
        // Create an instance of DeliveryData (subject)
        DeliveryData topic = new DeliveryData();

        // Create instances of observers
        Observer obj1 = new Seller();
        Observer obj2 = new User();
        Observer obj3 = new DeliveryWarehouseCenter();

        // Register observers with the subject
        topic.register(obj1);
        topic.register(obj2);
        topic.register(obj3);

        // Change the location and notify observers
        topic.locationChanged();

        // Unregister an observer
        topic.unregister(obj3);

        System.out.println();

        // Change the location and notify observers again
        topic.locationChanged();
    }
}
