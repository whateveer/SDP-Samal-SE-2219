// Package declaration for the flyweight design pattern
package flyweight_design_pattern;

// Importing necessary Java utilities
import java.util.HashMap;
import java.util.Random;

// Employee interface defining common behavior for employees
interface Employee
{
  public void assignSkill(String skill); // Method to assign a skill to an employee
  public void task(); // Method to perform a task
}

// Developer class implementing the Employee interface
class Developer implements Employee
{

  private final String JOB; // Constant job description for a developer
  private String skill; // Skill assigned to the developer

  // Constructor for Developer class
  public Developer()
  {
    JOB = "Fix the issue"; // Initializing the job description for a developer
  }

  @Override
  public void assignSkill(String skill) // Method to assign a skill to a developer
  {
    this.skill = skill;
  }

  @Override
  public void task()  // Method to perform a task for a developer
  {
    System.out.println("Developer with skill: " + this.skill + " with Job: " + JOB);
  }

}

// Tester class implementing the Employee interface
class Tester implements Employee
{
  private final String JOB; // Constant job description for a tester
  private String skill; // Skill assigned to the tester

  // Constructor for Tester class
  public Tester()
  {
    JOB = "Test the issue"; // Initializing the job description for a tester
  }

  @Override
  public void assignSkill(String skill) // Method to assign a skill to a tester
  {
    this.skill = skill;
  }

  @Override
  public void task() // Method to perform a task for a tester
  {
    System.out.println("Tester with Skill: " + this.skill + " with Job: " + JOB);
  }

}

// EmployeeFactory class responsible for creating and managing employees
class EmployeeFactory
{
  private static HashMap<String, Employee> m = new HashMap<String, Employee>(); // Hashmap to store employee instances

  // Method to get an employee instance based on the type
  public static Employee getEmployee(String type)
  {
    Employee p = null; // Initializing the employee instance to null

    if(m.get(type) != null) // Checking if the employee instance already exists
    {
      p = m.get(type);
    }
    else
    {
      switch(type) // Creating a new employee instance based on the type
      {
        case "Developer":
          System.out.println("Developer Created");
          p = new Developer();
          break;
        case "Tester":
          System.out.println("Tester Created");
          p = new Tester();
          break;
        default:
          System.out.println("No Such Employee");
      }

      m.put(type, p); // Adding the employee instance to the hashmap
    }
    return p; // Returning the employee instance
  }
}

// Main class for the Flyweight pattern example
public class FlyweightPattern
{
  private static String employeeType[] = {"Developer", "Tester"}; // Array of employee types
  private static String skills[] = {"Java", "C++", ".Net", "Python"}; // Array of skills

  // Main method to demonstrate the Flyweight pattern
  public static void main(String[] args)
  {
    for(int i = 0; i < 10; i++)  // Creating and using employee instances
    {
      Employee e = EmployeeFactory.getEmployee(getRandEmployee());
      e.assignSkill(getRandSkill());
      e.task();
    }
  }

  // Method to get a random employee type
  public static String getRandEmployee()
  {
    Random r = new Random();
    int randInt = r.nextInt(employeeType.length);
    return employeeType[randInt];
  }

  // Method to get a random skill
  public static String getRandSkill()
  {
    Random r = new Random();
    int randInt = r.nextInt(skills.length);
    return skills[randInt];
  }
}
