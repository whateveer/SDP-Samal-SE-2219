package bridge_design_pattern;  // Package for the bridge design pattern

abstract class TV
{
    Remote remote;  // Reference to the remote

    TV(Remote r)
    {
        this.remote = r;
    }

    abstract void on();  // Abstract method to turn the TV on
    abstract void off(); // Abstract method to turn the TV off
}

class Sony extends TV
{
    Remote remoteType; // Type of remote for Sony TV

    Sony(Remote r)
    {
        super(r);  // Call the superclass constructor
        this.remoteType = r;  // Initialize remoteType
    }

    public void on()
    {
        System.out.print("Sony TV ON: ");
        remoteType.on();  // Turn Sony TV on using the remote
    }

    public void off()
    {
        System.out.print("Sony TV OFF: ");
        remoteType.off();  // Turn Sony TV off using the remote
    }
}

class Philips extends TV
{
    Remote remoteType; // Type of remote for Philips TV

    Philips(Remote r)
    {
        super(r);  // Call the superclass constructor
        this.remoteType = r;  // Initialize remoteType
    }

    public void on()
    {
        System.out.print("Philips TV ON: ");
        remoteType.on();  // Turn Philips TV on using the remote
    }

    public void off()
    {
        System.out.print("Philips TV OFF: ");
        remoteType.off();  // Turn Philips TV off using the remote
    }
}

interface Remote
{
    public void on();  // Method to turn on the TV
    public void off(); // Method to turn off the TV
}

class OldRemote implements Remote
{
    @Override
    public void on()
    {
        System.out.println("ON with Old Remote");  // Implementing on() for old remote
    }

    @Override
    public void off()
    {
        System.out.println("OFF with old Remote");  // Implementing off() for old remote
    }
}

class NewRemote implements Remote
{
    @Override
    public void on()
    {
        System.out.println("ON with New Remote");  // Implementing on() for new remote
    }

    @Override
    public void off()
    {
        System.out.println("OFF with New Remote");  // Implementing off() for new remote
    }
}

public class BridgePattern
{
    public static void main(String[] args)
    {
        TV sonyOldRemote = new Sony(new OldRemote());  // Create a Sony TV with an old remote
        sonyOldRemote.on();  // Turn on the Sony TV using the old remote
        sonyOldRemote.off();  // Turn off the Sony TV using the old remote
        System.out.println();

        TV sonyNewRemote = new Sony(new NewRemote());  // Create a Sony TV with a new remote
        sonyNewRemote.on();  // Turn on the Sony TV using the new remote
        sonyNewRemote.off();  // Turn off the Sony TV using the new remote
        System.out.println();

        TV philipsOldRemote = new Philips(new OldRemote());  // Create a Philips TV with an old remote
        philipsOldRemote.on();  // Turn on the Philips TV using the old remote
        philipsOldRemote.off();  // Turn off the Philips TV using the old remote
        System.out.println();

        TV philipsNewRemote = new Philips(new NewRemote());  // Create a Philips TV with a new remote
        philipsNewRemote.on();  // Turn on the Philips TV using the new remote
        philipsNewRemote.off();  // Turn off the Philips TV using the new remote
    }
}
