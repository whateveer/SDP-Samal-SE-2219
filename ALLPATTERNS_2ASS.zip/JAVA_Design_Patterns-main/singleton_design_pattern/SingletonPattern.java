package singleton_design_pattern;  // Package declaration

class SingletonEagar  // SingletonEagar class
{
  private static SingletonEagar instance = new SingletonEagar();  // Eagerly initialized instance

  private SingletonEagar()  // Private constructor
  {
    // Constructor body (empty in this case)
  }

  public static SingletonEagar getInstance()  // Public method to get instance
  {
    return instance;
  }
}

class Singleton  // Singleton class
{
  private static Singleton instance;  // Singleton instance

  private Singleton()  // Private constructor
  {
    // Constructor body (empty in this case)
  }

  public static Singleton getInstance()  // Public method to get instance
  {
    if(instance == null)  // Check if instance is null
    {
      instance = new Singleton();  // Create new instance if null
    }
    return instance;  // Return the instance
  }
}

class SingletonSynchronizedMethod  // SingletonSynchronizedMethod class
{
  private static SingletonSynchronizedMethod instance;  // Singleton instance

  private SingletonSynchronizedMethod()  // Private constructor
  {
    // Constructor body (empty in this case)
  }

  public static synchronized SingletonSynchronizedMethod getInstance()  // Synchronized public method to get instance
  {
    if(instance == null)  // Check if instance is null
    {
      instance = new SingletonSynchronizedMethod();  // Create new instance if null
    }
    return instance;  // Return the instance
  }
}

class SingletonSynchronized  // SingletonSynchronized class
{
  private static SingletonSynchronized instance;  // Singleton instance

  private SingletonSynchronized()  // Private constructor
  {
    // Constructor body (empty in this case)
  }

  public static SingletonSynchronized getInstance()  // Public method to get instance
  {
    if(instance == null)  // Check if instance is null
    {
      synchronized (SingletonSynchronized.class)  // Synchronize on the class for thread safety
      {
        if(instance == null)  // Double-check if instance is still null
        {
          instance = new SingletonSynchronized();  // Create new instance if null
        }
      }
    }
    return instance;  // Return the instance
  }
}

public class SingletonPattern  // SingletonPattern class
{
  public static void main(String[] args)  // Main method
  {
    SingletonSynchronized instance = SingletonSynchronized.getInstance();  // Get an instance of SingletonSynchronized
    System.out.println(instance);  // Print the instance
    SingletonSynchronized instance1 = SingletonSynchronized.getInstance();  // Get another instance of SingletonSynchronized
    System.out.println(instance1);  // Print the instance
  }
}
